﻿using System;                       //Ryan Kemp
using System.Collections.Generic;   //20100423
using System.Text;
using System.Windows.Forms;
using static Task_1.Character;
using static Task_1.frmUI; 
    
    namespace Task_1
{



    class GameEngine
    {

        //2.5 shop object
        Shop shop;


        private Map map;
         public Map GetMap
        {
            get { return map; }
            set { map = value; }
        }

        bool playerMoved = false;
        bool playerAttacks = false;
        
       public GameEngine()
        {
            map = new Map(10, 10, 15, 15, 6,5);
            
            MoveEnemy();
            
        }

        public void MovePlayer(MovementDirection movement)
        {
            switch (movement)
            {
                case MovementDirection.up:
                    map.GetPlayer.Move(map.GetPlayer.ReturnMove(MovementDirection.up));
                    break;

                case MovementDirection.down:
                    map.GetPlayer.Move(map.GetPlayer.ReturnMove(MovementDirection.down));
                    break;

                case MovementDirection.left:
                    map.GetPlayer.Move(map.GetPlayer.ReturnMove(MovementDirection.left));
                    break;

                case MovementDirection.right:
                    map.GetPlayer.Move(map.GetPlayer.ReturnMove(MovementDirection.right));
                    break;
            }
           
        }

        public string PlayerAttack(int Enemy)
        {
            bool EnemyInRange = false;

            foreach(Tile T in map.GetPlayer.Vision)
            {
                if(T.getX == map.GetEnemies[Enemy].getX && (T.getY == map.GetEnemies[Enemy].getY))
                {
                    EnemyInRange = true;
                    break;
                }
            }
             
            if (EnemyInRange)
            {
                map.GetPlayer.attack(map.GetEnemies[Enemy]);
                return "You did attack" + map.GetPlayer.getDamage + " damage to a " + map.GetEnemies[Enemy].GetTileType
                +"they now have" + map.GetEnemies[Enemy].getHP + "HP";
                playerAttacks = true;
            }
            else
            {
                return "Target was not in range";
            }
        }        

        public override string ToString()
        {
           return map.DrawMap();
        }


        //Enemy attacking
        public string EnemyAttacks(int Character) {

            return null;

        }

        //Enemy movement
        public void MoveEnemy() {

            /*
            if (playerMoved == true) {

                EnemyAttacks();
            }

            if (playerAttacks == true) {
                EnemyAttacks();

            }
            */
            MessageBox.Show("hello");
            

        }


        //bool CheckValidMove(MovementDirection charactermove) {
        //    bool valid = false;

        //    switch (charactermove) {
        //        case MovementDirection.right:
        //            if (Vision[2].GetType() == typeof(EmptyTile) || Vision[2].GetType() == typeof(Gold)) {
        //                valid = true;
        //                break;
        //            }
        //            break;
        //        case MovementDirection.left:
        //            if (Vision[3].GetType() == typeof(EmptyTile) || Vision[3].GetType() == typeof(Gold)) {
        //                valid = true;
        //                break;
        //            }
        //            break;
        //        case MovementDirection.down:
        //            if (Vision[1].GetType() == typeof(EmptyTile) || Vision[1].GetType() == typeof(Gold)) {
        //                valid = true;
        //                break;
        //            }
        //            break;
        //        case MovementDirection.up:
        //            if (Vision[0].GetType() == typeof(EmptyTile) || Vision[0].GetType() == typeof(Gold)) {
        //                valid = true;
        //                break;
        //            }
        //            break;
        //    }
        //    return valid;
        //}

    }
}
