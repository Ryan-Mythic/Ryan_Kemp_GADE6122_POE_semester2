﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Task_1 {
      abstract class Leader : Enemy{

        private Tile leadersTarget;

        public void setLeadersTarget(Tile leadersTarget) {
            this.leadersTarget = leadersTarget;
        }

        public Tile getLeadersTarget() {
            return this.leadersTarget;
        }

        protected Leader(int x, int y, TileType tileType, char symbol, int dmg, int EnemyHP, int MaxEnemyHP) : base(x, y, tileType, symbol, 2, 20, MaxEnemyHP) {
            
        }

        public override MovementDirection ReturnMove(MovementDirection move) {

            MovementDirection heroCurrentPosition = new Hero(0, 0, TileType.Hero).getTargetCurrentPosition();
            MovementDirection leadersPosition = MovementDirection.idle;

            //if hero's current position is above then make leader go up
            if (heroCurrentPosition == MovementDirection.up) {
                leadersPosition = MovementDirection.up;
                /*
                    if leaders vision is blocked by obstacle 
                    then look for a random direction until not blocked by obstacle
                */
                for (int x = 0; x < 4; x++) {
                    while (Vision[x].GetType() != typeof(Obstacle)) {
                        leadersPosition = getRandomDirection();
                    }
                }
            } else

            //if hero's current position is down then make leader go down
            if (heroCurrentPosition == MovementDirection.down) {
                leadersPosition = MovementDirection.down;
                /*
                    if leaders vision is blocked by obstacle 
                    then look for a random direction until not blocked by obstacle
                */
                for (int x = 0; x < 4; x++) {
                    while (Vision[x].GetType() != typeof(Obstacle)) {
                        leadersPosition = getRandomDirection();
                    }
                }
            } else

            //if hero's current position is left then make leader go left
            if(heroCurrentPosition == MovementDirection.left) {
                leadersPosition = MovementDirection.left;
                /*
                    if leaders vision is blocked by obstacle 
                    then look for a random direction until not blocked by obstacle
                */
                for (int x = 0; x < 4; x++) {
                    while (Vision[x].GetType() != typeof(Obstacle)) {
                        leadersPosition = getRandomDirection();
                    }
                }
            } else

            if (heroCurrentPosition == MovementDirection.right) {
                leadersPosition = MovementDirection.right;
                /*
                    if leaders vision is blocked by obstacle 
                    then look for a random direction until not blocked by obstacle
                */
                for (int x = 0; x < 4; x++) {
                    while (Vision[x].GetType() != typeof(Obstacle)) {
                        leadersPosition = getRandomDirection();
                    }
                }
            }

            return leadersPosition;
        }



        public MovementDirection getRandomDirection() { 
            Array directions = Enum.GetValues(typeof(MovementDirection));
            Random random = new Random();
            MovementDirection randomDirection = (MovementDirection)directions.GetValue(random.Next(directions.Length));
            return randomDirection;
        }




    }
}
