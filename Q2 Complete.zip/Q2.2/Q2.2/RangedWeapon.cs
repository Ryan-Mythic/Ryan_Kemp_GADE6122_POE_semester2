﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Task_1 {
    abstract class RangedWeapon : Weapon {

        protected int _X;
        protected int _Y;
        protected char WeaponSymbol;
        protected Types RangedWeaponType;

        public enum Types {
            Rifle,
            Longbow
        }

        public RangedWeapon(int x, int y, TileType tileType, char symbol) : base(x, y, tileType, symbol) {
            _X = x;
            _Y = y;
            WeaponSymbol = symbol;
        }

        
        public RangedWeapon(Types rangedWeaponType, int durability, int x, int y, TileType tileType, char symbol) : base(x, y, tileType, symbol) {
            //SWITCHING BASED ON WEAPON------
            int flag = -1;
            if (rangedWeaponType == Types.Rifle) {
                flag = 0;//rifle
            } else if (rangedWeaponType == Types.Longbow) {
                flag = 1;//longbow
            }
            switch (flag) {
                case 0:
                    setWeaponType("Rifle");
                    setWeaponDurability(3);
                    setWeaponDamage(5);
                    setWeaponCost(7);
                    break;
                case 1:
                    setWeaponType("Longbow");
                    setWeaponDurability(4);
                    setWeaponDamage(2);
                    setWeaponCost(6);
                    break;
            }
            //----------------------------------
        }


       

        public override int Range {
            get { return range; }
            set { range = value; }
        }




       
    }
}
