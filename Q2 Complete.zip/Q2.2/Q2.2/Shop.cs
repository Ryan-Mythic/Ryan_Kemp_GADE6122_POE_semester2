﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task_1 {

    abstract class Shop  {

        private Weapon[] weapons;
        Random random;
        Character character;
        int weaponCost = 0;
        public enum Weapon {
            Rifle,
            Longbow,
            Longsword,
            Dagger,
            Barehand
        }


        public Shop(Character character) {
            weapons = new Weapon[3];
            random = new Random();

            //adding random weapon to weapon array
            for(int x=0; x < weapons.Length; x++) {
                weapons[x] = RandomWeapon();
            }
        }

        //Getting random weapon
        private Weapon RandomWeapon() {
            int i = random.Next(1, 5);
            Weapon randomWeapon = Weapon.Barehand;
            if (i == 1) {
               randomWeapon =  Weapon.Rifle;
            } else if (i == 2) {
                randomWeapon = Weapon.Longsword;
            } else if (i == 3) {
                randomWeapon = Weapon.Longbow;
            } else if (i == 4) {
                randomWeapon = Weapon.Dagger;
            }

            return randomWeapon;
        } 

        public bool CanBuy(int num) {
            int wallet = character.getPurse;
          
                Weapon w= weapons[num];     
                switch (w) {
                    case Weapon.Rifle:
                    weaponCost = 7;
                        if (wallet > weaponCost) {
                            return true;
                        }
                        break;
                    case Weapon.Longsword:
                    weaponCost = 5;
                        if (wallet > weaponCost) {
                            return true;
                        }
                        break;
                    case Weapon.Longbow:
                    weaponCost = 6;
                        if (wallet > weaponCost) {
                            return true;
                        }
                        break;
                    case Weapon.Dagger:
                    weaponCost = 3;
                        if(wallet > weaponCost) {
                            return true;
                        }
                    break;
            }

            return false;
        }

        
        public void Buy(int num) {
            int wallet = character.getPurse;    //getting the gold
            if (CanBuy(num)) {
                character.setPurse(wallet - weaponCost);
                PickUp(num);
            }
        
        }
        public void PickUp(int slot) {
            weapons[slot] = RandomWeapon();
        }

        public string DisplayWeapon(int num) {
            Weapon weapon = weapons[num];
            string output = "";
            switch (weapon) {
                case Weapon.Rifle:
                    output += "Buy Rifle (X " + weaponCost+" )";
                    break;
                case Weapon.Dagger:
                    output += "Buy Dagger (X " + weaponCost + " )";
                    break;
                case Weapon.Longsword:
                    output += "Buy Longsword (X " + weaponCost + " )";
                    break;
                case Weapon.Longbow:
                    output += "Buy Longbow (X " + weaponCost + " )";
                    break;
            }

            return output;
        }


}
}
